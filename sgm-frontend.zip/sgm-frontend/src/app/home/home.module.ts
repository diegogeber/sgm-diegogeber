import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FirstPageComponent } from "./first-page/first-page.component";

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [FirstPageComponent]
})
export class HomeModule { }
