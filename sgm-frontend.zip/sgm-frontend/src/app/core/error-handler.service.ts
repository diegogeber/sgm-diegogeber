import { Injectable , NgZone  } from '@angular/core';
import { ToastyService } from 'ng2-toasty';

@Injectable()
export class ErrorHandlerService {

  constructor(private toastyService: ToastyService , private ngZone : NgZone) { }

  handle(errorResponse: any){
    let msg: string;

    if(typeof errorResponse === 'string'){
      msg = errorResponse;
    }else{
      msg = '<strong>Erro ao processar serviço. Tente Novamente</strong>';
    }
        this.ngZone.run(() => {
            this.toastyService.error(msg);
        });  
  }

}
