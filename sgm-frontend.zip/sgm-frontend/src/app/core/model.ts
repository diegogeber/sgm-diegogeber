export class Projeto {
    id : number;
    nome : string;
    descricao: string;
    responsavel:string;
    dataInicio:Date;
    dataFim:Date;
    custo:string;
}

export class Usuario {
    id : number;
    nome: string;
    email: string;
    senha: string;
    perfil: string;
    cpf: string;
}

export class LoginDto {
    email: string;
    senha: string;
}

export class Consult{
    tributo: string;
    numeroInscricao: string;
    tipoOrganizacao: string;
}

export class RetornoIPTU {
    tributo : string;
    numeroInscricao: string;
    competencia: string;
    endereco: string;
    tipoOrganizacao: string;
    codigoBarras: string;
    vencimento: string;
    proprietario: string;
    valor: string;
}