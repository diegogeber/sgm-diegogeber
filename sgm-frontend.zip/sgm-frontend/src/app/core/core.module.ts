import { NgModule, LOCALE_ID } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConfirmDialogModule } from 'primeng/components/confirmdialog/confirmdialog';
import { ToastyModule } from 'ng2-toasty';

import { NavbarComponent} from './navbar/navbar.component';
import { ErrorHandlerService } from './error-handler.service';
import { ProjetoService } from '../projetos/projeto.service';
import { UsuarioService } from '../usuarios/usuario.service';
import {  RouterModule } from '@angular/router';
import { PaginaNaoEncontradaComponent } from './pagina-nao-encontrada.component';
import { AuthService } from "app/seguranca/auth.service";
import {JwtHelper} from 'angular2-jwt';
import { ConsutaIptuService } from "app/iptu/consuta-iptu.service";
import { NaoAutorizadoComponent } from './nao-autorizado.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    ToastyModule.forRoot(),
    ConfirmDialogModule
  ],
  declarations: [NavbarComponent, PaginaNaoEncontradaComponent, NaoAutorizadoComponent],
  exports: [NavbarComponent,ToastyModule],
  providers:[ 
    ErrorHandlerService,
    ProjetoService,UsuarioService,{provide: LOCALE_ID , useValue: 'pt-BR'}, AuthService,JwtHelper,ConsutaIptuService
  ]
})
export class CoreModule { }
