import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {InputTextModule} from 'primeng/components/inputtext/inputtext';
import {ButtonModule} from 'primeng/components/button/button';
import {DataTableModule} from 'primeng/components/datatable/datatable';
import {CalendarModule} from 'primeng/components/calendar/calendar';
import {CurrencyMaskModule} from 'ng2-currency-mask';
import {DropdownModule} from 'primeng/components/dropdown/dropdown';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router'
import { AppComponent } from './app.component';
import { ProjetosPesquisaComponent } from './projetos/projetos-pesquisa/projetos-pesquisa.component';
import { NavbarComponent } from './core/navbar/navbar.component';
import { CoreModule } from './core/core.module'
import { UsuarioComponent } from './usuarios/usuario/usuario.component';
import { ProjetoCadastroComponent } from './projetos/projeto-cadastro/projeto-cadastro.component';
import { UsuarioCadastroComponent } from './usuarios/usuario-cadastro/usuario-cadastro.component';
import { MessageComponent } from './shared/message/message.component';
import { FirstPageComponent } from './home/first-page/first-page.component';
import { HttpModule } from '@angular/http';
import { PaginaNaoEncontradaComponent } from './core/pagina-nao-encontrada.component';
import { LoginFormComponent } from "app/seguranca/login-form/login-form.component";
import { ConsultaIptuComponent } from "app/iptu/consulta-iptu/consulta-iptu.component";
import { NaoAutorizadoComponent } from './core/nao-autorizado.component';


const routes: Routes = [
  { path: '' , redirectTo: 'projetos' , pathMatch: 'full' },
  { path: 'projetos' , component: ProjetosPesquisaComponent },
  { path: 'projetos/novo' , component: ProjetoCadastroComponent },
  { path: 'projetos/:codigo' , component: ProjetoCadastroComponent },
  { path: 'usuarios' , component: UsuarioComponent },
  { path: 'usuarios/novo' , component: UsuarioCadastroComponent},
  { path: 'pagina-nao-encontrada' , component: PaginaNaoEncontradaComponent},
  { path: 'login' , component: LoginFormComponent},
  { path: 'iptu' , component: ConsultaIptuComponent},
  { path: 'nao-autorizado' , component: NaoAutorizadoComponent},
  { path: '**' , redirectTo: 'pagina-nao-encontrada'},
];

@NgModule({
  
  imports: [
    
    RouterModule.forRoot(routes),
    
  ], 
  exports: [RouterModule]
})
export class AppRoutingModule { }