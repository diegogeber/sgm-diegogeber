import { Component, OnInit } from '@angular/core';
import { UsuarioService } from '../usuario.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.component.html',
  styleUrls: ['./usuario.component.css']
})
export class UsuarioComponent implements OnInit {
  nome : string;
  usuarios = [];

  constructor(private usuarioService: UsuarioService, private router: Router){}

  ngOnInit(){
    if(!localStorage.getItem('token')){
      this.router.navigate(['/nao-autorizado']);
    }
    this.pesquisar();
  }

  pesquisar(){
    this.usuarioService.pesquisar({ nome: this.nome})
      .then(usuarios => this.usuarios = usuarios);
  }

}
