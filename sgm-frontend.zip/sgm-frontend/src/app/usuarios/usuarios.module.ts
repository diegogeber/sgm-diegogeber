import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsuarioComponent } from "app/usuarios/usuario/usuario.component";
import { UsuarioCadastroComponent } from "app/usuarios/usuario-cadastro/usuario-cadastro.component";
import { SharedModule } from "app/shared/shared.module";
import {  RouterModule } from '@angular/router'

@NgModule({
  imports: [
    CommonModule,
    RouterModule
  ],
  declarations: [
    UsuarioComponent,
    UsuarioCadastroComponent,
    SharedModule
  ],
  exports:[
    UsuarioComponent,
    UsuarioCadastroComponent
  ]
})
export class UsuariosModule { }
