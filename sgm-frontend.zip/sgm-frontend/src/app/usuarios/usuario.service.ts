import { Injectable } from '@angular/core';
import { Http,Headers } from '@angular/http';
import  'rxjs/add/operator/toPromise';
import { Usuario } from "app/core/model";
import { AuthHttp } from "angular2-jwt/angular2-jwt";

export interface UsuarioFiltro {
  nome : string;
}

@Injectable()
export class UsuarioService {

  usuarioUrl = "http://localhost:8080/usuario";

  constructor(private http: Http) { }

  pesquisar(filtro:any): Promise<any>{
    const params = new URLSearchParams();
    const headers = new Headers();
    headers.append("Authorization" , "Bearer " + localStorage.getItem("token") );
    if(filtro.nome){
      params.set('nome', filtro.nome)
    }

    return this.http.get(`${this.usuarioUrl}` , {headers: headers , search : filtro})
      .toPromise()
      .then(response => response.json())
  }

  add(usuario: Usuario) : Promise<Usuario>{
    const headers = new Headers();
    headers.append('Content-Type',  'application/json')
    headers.append("Authorization" , "Bearer " + localStorage.getItem("token") );
    return this.http.post(this.usuarioUrl, JSON.stringify(usuario), {headers})
      .toPromise()
      .then(response => response.json());
  }

}
