import { Component, OnInit } from '@angular/core';
import { FormControl } from "@angular/forms/src/model";
import { ToastyService } from "ng2-toasty";
import { ErrorHandlerService } from '../../core/error-handler.service';
import { Usuario } from "app/core/model";
import { UsuarioService } from "app/usuarios/usuario.service";




@Component({
  selector: 'app-usuario-cadastro',
  templateUrl: './usuario-cadastro.component.html',
  styleUrls: ['./usuario-cadastro.component.css']
})
export class UsuarioCadastroComponent implements OnInit {

  perfis = [{label:'Administrador' , value:'ADMINISTRADOR'},
            {label:'Servidor' , value:'SERVIDOR'},
            {label:'Cidadão' , value:'CIDADAO'}
  ];

  usuario = new Usuario();

  constructor(private errorHandler: ErrorHandlerService, 
  private usuarioService: UsuarioService,
  private toasty: ToastyService) { }

  ngOnInit() {
  }

  salvar(form : FormControl){
      this.usuario.senha = this.usuario.cpf;
      this.usuarioService.add(this.usuario)
        .then(res => this.toasty.success("Cadastrado com Sucesso"))
        .catch(err => this.errorHandler.handle(err))
  }

}
