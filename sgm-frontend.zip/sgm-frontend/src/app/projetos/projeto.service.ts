import { Injectable } from '@angular/core';
import { Http,Headers } from '@angular/http';
import  'rxjs/add/operator/toPromise';
import { Projeto } from "app/core/model";
import * as moment from 'moment';
import { AuthHttp } from "angular2-jwt/angular2-jwt";

export interface ProjetoFiltro {
  nome : string;
}

@Injectable()
export class ProjetoService {

  projetoUrl = "http://localhost:8080/projeto";

  constructor(private http: Http) { }

  pesquisar(filtro:any): Promise<any>{
    const params = new URLSearchParams();
    const headers = new Headers();
    headers.append("Authorization" , "Bearer " + localStorage.getItem("token") );
    if(filtro.nome){
      params.set('nome', filtro.nome)
    }

    return this.http.get(`${this.projetoUrl}` , {headers: headers , search : filtro})
      .toPromise()
      .then(response => response.json())
  }

  add(projeto: Projeto) : Promise<Projeto>{
    const headers = new Headers();
    headers.append('Content-Type',  'application/json')
    headers.append("Authorization" , "Bearer " + localStorage.getItem("token") ); 
    return this.http.post(this.projetoUrl, JSON.stringify(projeto), {headers})
      .toPromise()
      .then(response => response.json());
  }

  atualizar(projeto: Projeto): Promise<Projeto> {
    const headers = new Headers();
     headers.append('Content-Type',  'application/json')
     headers.append("Authorization" , "Bearer " + localStorage.getItem("token") );
    return this.http.put(this.projetoUrl + "/" + projeto.id , JSON.stringify(projeto), {headers})
      .toPromise()
      .then(response => response.json());
  }

  buscarPorCodigo(codigo: number): Promise<Projeto>{
    const headers = new Headers();
    headers.append('Content-Type',  'application/json')
    headers.append("Authorization" , "Bearer " + localStorage.getItem("token") );
    return this.http.get(`${this.projetoUrl}` +"/" + codigo , {headers: headers})
      .toPromise()
      .then(response => {
        const pjt = response.json() as Projeto;
        this.converteStringsParaDatas([pjt]);        
        return pjt;
      });

  }

  private converteStringsParaDatas(projetos : Projeto[]){
      for(const projeto of projetos){
        projeto.dataInicio = moment(projeto.dataInicio, 'YYYY-MM-DD').toDate();

        if(projeto.dataFim){
            projeto.dataFim = moment(projeto.dataFim, 'YYYY-MM-DD').toDate();
        }
      }
  }

}
