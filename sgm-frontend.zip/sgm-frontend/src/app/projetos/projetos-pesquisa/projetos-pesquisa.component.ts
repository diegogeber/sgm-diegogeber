import { Component, OnInit } from '@angular/core';
import { ProjetoService } from '../projeto.service';
import { ToastyService } from 'ng2-toasty';
import { ErrorHandlerService } from '../../core/error-handler.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-projetos-pesquisa',
  templateUrl: './projetos-pesquisa.component.html',
  styleUrls: ['./projetos-pesquisa.component.css']
})
export class ProjetosPesquisaComponent implements OnInit {

  nome: string;
  projetos = [];

  constructor(private projetoService: ProjetoService,
              private toasty: ToastyService,
              private errorHandlerService: ErrorHandlerService,
              private router: Router){}

  ngOnInit(){
    if(!localStorage.getItem('token')){
      this.router.navigate(['/nao-autorizado']);
    }
    this.pesquisar();
  }

  pesquisar(){
    this.projetoService.pesquisar({ nome: this.nome})
      .then(projetos => this.projetos = projetos)
      .catch(erro => this.errorHandlerService.handle(erro));
  }

}
