import { Component, OnInit } from '@angular/core';
import { ErrorHandlerService } from '../../core/error-handler.service'
import { Projeto } from "app/core/model";
import { FormControl } from "@angular/forms/src/model";
import { ProjetoService } from "app/projetos/projeto.service";
import { ToastyService } from "ng2-toasty";
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-projeto-cadastro',
  templateUrl: './projeto-cadastro.component.html',
  styleUrls: ['./projeto-cadastro.component.css']
})
export class ProjetoCadastroComponent implements OnInit {

  projeto = new Projeto();

  constructor(private errorHandler: ErrorHandlerService, 
    private projetoService: ProjetoService,
    private toasty: ToastyService,
    private route: ActivatedRoute,
    private router: Router
    ) { }

  ngOnInit() {
    
    if(!localStorage.getItem('token')){
      this.router.navigate(['/nao-autorizado']);
    }

    const codigo = this.route.snapshot.params['codigo'];
    if(codigo){
      this.carregar(codigo);
    }
  }

  carregar(codigo :number){
    
      this.projetoService.buscarPorCodigo(codigo)
        .then(res => {
          this.projeto = res;
        })
        .catch(erro => this.errorHandler.handle);
  }

  get editando(){
    return Boolean(this.projeto.id);
  }

  salvar(form: FormControl){
      if(this.editando){
        this.atualizar(form);
      }else{
        this.add(form);
      }
  }
      
  add(form : FormControl){
      console.log(this.projeto);
      this.projetoService.add(this.projeto)
        .then(res => {
          this.toasty.success("Cadastrado com Sucesso")
          this.router.navigate(['/projetos']);
        })
        .catch(err => this.errorHandler.handle(err))
  }

  atualizar(form : FormControl){
      this.projetoService.atualizar(this.projeto)
        .then(res => {
          this.toasty.success("Cadastrado com Sucesso");
        })
        .catch(err => this.errorHandler.handle(err))
  }

}
