import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProjetoCadastroComponent } from "app/projetos/projeto-cadastro/projeto-cadastro.component";
import { ProjetosPesquisaComponent } from "app/projetos/projetos-pesquisa/projetos-pesquisa.component";
import { SharedModule } from "app/shared/shared.module";
import {  RouterModule } from '@angular/router'
import { FormControl } from "@angular/forms/src/model";
import { ProjetosRoutingModule} from './projetos-routing.module';


@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    ProjetoCadastroComponent,
    ProjetosPesquisaComponent,
    SharedModule,
    ProjetosRoutingModule
    
  ],
  exports: [
    ProjetoCadastroComponent,
    ProjetosPesquisaComponent
  ]
})
export class ProjetosModule { }
