import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProjetoCadastroComponent } from "app/projetos/projeto-cadastro/projeto-cadastro.component";
import { ProjetosPesquisaComponent } from "app/projetos/projetos-pesquisa/projetos-pesquisa.component";
import { SharedModule } from "app/shared/shared.module";
import {  RouterModule, Routes } from '@angular/router'
import { FormControl } from "@angular/forms/src/model";

const routes: Routes = [
  
  { path: 'projetos' , component: ProjetosPesquisaComponent },
  { path: 'projetos/novo' , component: ProjetoCadastroComponent },
  { path: 'projetos/:codigo' , component: ProjetoCadastroComponent }

];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class ProjetosRoutingModule { }
