import { Component, OnInit } from '@angular/core';
import { AuthService } from "app/seguranca/auth.service";
import { LoginDto } from "app/core/model";
import { ErrorHandlerService } from "app/core/error-handler.service";
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent implements OnInit {
  loginDto = new LoginDto();
  constructor(private auth : AuthService, private errorHandler: ErrorHandlerService,private router:Router ) { }

  ngOnInit() {
  }

  
  login(){
    this.auth.login(this.loginDto.email, this.loginDto.senha)
      .then(() =>  this.router.navigate(['/projetos']))
      .catch(err => {
        this.errorHandler.handle(err);
      });
  }

}
