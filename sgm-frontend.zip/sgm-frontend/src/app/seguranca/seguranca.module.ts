import { NgModule } from '@angular/core';
import { Http, RequestOptions } from '@angular/http';
import { CommonModule } from '@angular/common';
import { LoginFormComponent } from './login-form/login-form.component';
import { AuthHttp,AuthConfig} from 'angular2-jwt';
import { LogoutService } from "app/seguranca/logout.service";
import { AuthGuard } from "app/seguranca/auth.guard";

export function authHttpServiceFactory(http: Http, options: RequestOptions ){
  return new AuthHttp(new AuthConfig(), http , options);
}

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LoginFormComponent],
  providers: [
    AuthGuard,
    {
      provide: AuthHttp,
      useFactory: authHttpServiceFactory,
      deps: [Http, RequestOptions]
   }
  ]
})
export class SegurancaModule { }
