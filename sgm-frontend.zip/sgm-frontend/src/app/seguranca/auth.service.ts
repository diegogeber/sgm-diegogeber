import { Injectable } from '@angular/core';
import { Http,Headers } from '@angular/http';
import { LoginDto } from 'app/core/model';
import 'rxjs/add/operator/toPromise';
import { JwtHelper } from "angular2-jwt/angular2-jwt";

@Injectable()
export class AuthService {

  authTokenUrl = 'http://localhost:8080/auth';
  loginDto = new LoginDto();
  jwtPayload: any;

  constructor(private jwtHelper : JwtHelper, private http: Http) {
    this.carregarToken();
  }

  limparAccessToken(){
    localStorage.clear();
    this.jwtPayload = null;
  }

  temPermissao(permissao: string){
    return this.jwtPayload && this.jwtPayload.role[0].authority == permissao;
  }

  login(usuario: string , senha: string): Promise<void> {
      const headers = new Headers();
      headers.append("Content-Type","application/json");
      
      this.loginDto.email = usuario;
      this.loginDto.senha = senha;

      const body = this.loginDto;

      return this.http.post(this.authTokenUrl , body , {headers}).toPromise()
      .then(response => {
        
        this.armazenarToken(response.json().token);
      })
      .catch(err => {
        if(err.status === 400){
          return Promise.reject("email/senha inválidos");
        }else{
          return Promise.reject("Erro ao tentar fazer login");
        }
      });

  }

  private armazenarToken(token: string){
      this.jwtPayload = this.jwtHelper.decodeToken(token);
      localStorage.setItem('token' , token);
  }

  private carregarToken(){
    const token = localStorage.getItem('token');
    if(token){
      this.armazenarToken(token);
    }
  }
}
