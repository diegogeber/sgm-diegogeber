import { Injectable } from '@angular/core';
import { AuthHttp } from "angular2-jwt/angular2-jwt";
import { AuthService } from "app/seguranca/auth.service";

@Injectable()
export class LogoutService {

  constructor(private http: AuthHttp, private auth: AuthService) { }

  logout(){
    return this.http.delete("http://localhost:8080/reset" , { withCredentials: true})
      .toPromise()
      .then(() => {
        this.auth.limparAccessToken();
      })
  }

}
