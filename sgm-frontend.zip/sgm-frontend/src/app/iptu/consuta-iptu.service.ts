import { Injectable } from '@angular/core';
import { Http,Headers } from '@angular/http';
import  'rxjs/add/operator/toPromise';
import { Usuario } from "app/core/model";


export interface IptuFiltro {
  tributo : string;
  numeroInscricao: string;
  tipoOrganizacao: string;
}

@Injectable()
export class ConsutaIptuService {

  consultaUrl = "http://localhost:8080/tributo";

  constructor(private http: Http) { }

  pesquisar(filtro:any): Promise<any>{
    const params = new URLSearchParams();
    const headers = new Headers();
    headers.append("Authorization" , "Bearer " + localStorage.getItem("token") );
    
    params.set('tributo', filtro.tributo)
    params.set('numeroInscricao',filtro.numeroInscricao );
    params.set('tipoOrganizacao',filtro.tipoOrganizacao);

    console.log(filtro);

    return this.http.get(`${this.consultaUrl}`  , {headers: headers , search : filtro})
      .toPromise()
      .then(response => response.json())
  }

}
