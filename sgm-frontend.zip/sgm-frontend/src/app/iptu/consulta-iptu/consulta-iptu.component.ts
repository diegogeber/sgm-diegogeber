import { Component, OnInit } from '@angular/core';
import { Consult, RetornoIPTU } from "app/core/model";
import { FormControl } from "@angular/forms";
import { ConsutaIptuService } from "app/iptu/consuta-iptu.service";
//import { ConsultaIptuService } from "app/consulta-iptu.service";

@Component({
  selector: 'app-consulta-iptu',
  templateUrl: './consulta-iptu.component.html',
  styleUrls: ['./consulta-iptu.component.css']
})

export class ConsultaIptuComponent implements OnInit {
  tipoImposto = [{label:'Selecione' , value:''},{label:'IPTU' , value:'IPTU'},
            {label:'ITR' , value:'ITR'}
  ];

  consult = new Consult();
  retorno = new RetornoIPTU();
  data = [];

  tipoPessoa = [{label:'Selecione' , value:''},{label:'PESSOA FISICA' , value:'PESSOA FISICA'},
            {label:'PESSOA JURIDICA' , value:'PESSOA JURIDICA'}
  ];
  constructor(private consultaIptuService : ConsutaIptuService) { }

  ngOnInit() {
  }

  pesquisar(){
    console.log(this.consult);
      this.consultaIptuService.pesquisar({ tributo : this.consult.tributo , numeroInscricao: this.consult.numeroInscricao,
  tipoOrganizacao: this.consult.tipoOrganizacao })
      .then(res => {
        this.retorno = res;
        this.data.push(this.retorno);
        console.log(this.retorno);
      });
  }

  temDado(){
    return this.data.length > 0;
  }

}
