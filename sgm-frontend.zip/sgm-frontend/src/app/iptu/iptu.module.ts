import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConsultaIptuComponent } from './consulta-iptu/consulta-iptu.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [ConsultaIptuComponent],
  exports:[ ConsultaIptuComponent]
})
export class IptuModule { }
